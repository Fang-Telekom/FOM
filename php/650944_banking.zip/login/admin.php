<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <title> Admin Page </title>
    <?php include "header.php"; ?>

    <style>
    .body{       
        width:80%;
        margin: auto;
        background-color: white;
		}
        </style>
</head>

<body>
    <div class="body">
    <?php include "users.php"; ?>
    </div>
</body>

</html>
